# pcileech-cardreader
pcileech-fpga with SD card reader card emulation (Alcor Micro PCIe Card Reader)


# Pictures
![Alcor](https://i.imgur.com/kzmqSIH.png)

# Usage
This firmware was created for researching purposes only.  

# Original project by Ulf Frisk
Original project can be found from https://github.com/ufrisk/pcileech-fpga/  

# Anti-Cheats
This project was created to test current top Anti-Cheats against FPGA approach with minimal effort / knowledge.  

This demonstration project have flaw on release state.
Otherwise, it got pefectly abused for more than 115 days+ on all anti-fun platform (except VGK).

https://www.faceit.com/en/players/kemeryx

This is also detected by drvscan : https://github.com/ekknod/drvscan recently.
Congratulations to Finland and all his innovative way of targetting rogue fpga.

Recently, 3 randoms guys got banned in the latest wawe, they do have used this project. 
So consider this project as unsafe.

# Donor device 

https://www.amazon.fr/dp/B077NF33TX
